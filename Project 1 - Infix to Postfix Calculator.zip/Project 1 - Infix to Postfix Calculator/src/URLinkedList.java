import java.util.Collection;
import java.util.Iterator;
import java.lang.IndexOutOfBoundsException;


public class URLinkedList<E> implements URList<E> {
    public URNode<E> head;
    public URNode<E> tail;
    private int count = 0;

    public URLinkedList() {

        head = tail = new URNode<E>(null, null);
    }

    // Appends the specified element to the end of this list
    public boolean add(E e) {

        URNode<E> entry = new URNode<E>(e, null, null);

        //empty list
        if (head.next() == null) {
            head.setNext(entry);
            tail = entry;
            entry.setPrev(head);
            count++;
            return true;
        }
        //non-empty list
        else {
            tail.setNext(entry);
            entry.setPrev(tail);
            tail = entry;
            count++;
            return true;
        }
    }

    // Inserts the specified element at the specified position in this list
    public void add(int index, E element) {
        if (index < 0 || index > count)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + count);

        //move to index;
        URNode<E> predecessor = head;
        for (int i = 0; i < index - 1; i++) {
            predecessor = predecessor.next();
        }

        //if list is empty
        if (head.next() == null) {
            URNode<E> entry = new URNode<E>(element, head, null);
            head.setNext(entry);
            count++;
        }

        //else
        else {
            URNode<E> entry = new URNode<E>(element, predecessor, predecessor.next());
            predecessor.next().setPrev(entry);
            predecessor.setNext(entry);
            count++;
        }
    }

    // Appends all of the elements in the specified collection to the end of this list,
    // in the order that they are returned by the specified collection's iterator
    public boolean addAll(Collection<? extends E> c) {
        addAll(count, c);
        return true;
    }

    // Inserts all of the elements in the specified collection into this list
    // at the specified position

    public boolean addAll(int index, Collection<? extends E> c) {
        if (index < 0 || index > count)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + count);

        Iterator<? extends E> iter = c.iterator();

        URNode<E> successor = head;
        URNode<E> predecessor = head;
        if (index != count) {
            for (int i = 0; i <= index; i++) {
                successor = successor.next();
            }
            predecessor = successor.prev();
        }

        URNode<E> dummytail = tail;

        if (index == count) {
            dummytail = new URNode<E>(null, tail, null);
            predecessor = tail;
            successor = dummytail;
        }

        while (iter.hasNext()) {
            URNode<E> entry = new URNode<E>(iter.next(), predecessor, successor);
            predecessor.setNext(entry);
            predecessor = entry;
            count++;
        }
        if (successor != dummytail) successor.setPrev(predecessor);
        else if (successor == dummytail) predecessor.setNext(null);
        return true;
    }

    // Removes all of the elements from this list
    public void clear() {
        URNode<E> terminator = head.next();
        while (terminator != null) {
            URNode<E> next = terminator.next();
            terminator.setPrev(null);
            terminator.setNext(null);
            terminator.setElement(null);
            terminator = next;
        }
        count = 0;
        tail = head;
    }

    // Returns an iterator over the elements in this list in proper sequence.
    public Iterator<E> iterator() {
        return (Iterator<E>) new URLinkedListIterator<E>(this);
    }

    // Returns true if this list contains the specified element.
    public boolean contains(Object o) {
        if (indexOf(o) != -1) return true;
        return false;
    }

    // Returns true if this list contains all of the elements of the specified collection
    public boolean containsAll(Collection<?> c) {
        Iterator<?> checkList = c.iterator();

        while (checkList.hasNext()) {
            if (!contains(checkList.next())) return false;
        }
        return true;
    }

    // Compares the specified object with this list for equality.
    // Returns true if both contain the same elements. Ignore capacity
    @SuppressWarnings("unchecked")
    public boolean equals(Object o) {
        if (!(o instanceof URLinkedList)) return false;

        else {
            Iterator<E> iter_object = ((URLinkedList<E>) o).iterator();
            Iterator<E> iter_this = this.iterator();

            while (iter_object.hasNext()) {
                if (!iter_this.hasNext() || !iter_object.next().equals(iter_this.next())) {
                    return false;
                }
            }
            return true;
        }
    }

    // Returns the element at the specified position in this list.
    public E get(int index) {
        if (index < 0 || index > count)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + count);
        URNode<E> look = head;
        for (int i = 0; i <= index; i++) {
            look = look.next();
        }
        return look.element();
    }

    // Returns the index of the first occurrence of the specified element in this list,
    // or -1 if this list does not contain the element.
    public int indexOf(Object o) {
        // Iterator<E> iter = this.iterator();
        int index = 0;

        URNode<E> look = head;
        while (look.next() != null) {
            look = look.next();
            if (o == look.element()) return index;
            index++;
        }
        return -1;
    }

    // Returns true if this list contains no elements.
    public boolean isEmpty() {
        if (head.next() == null) return true;
        return false;
    }

    // Removes the element at the specified position in this list
    public E remove(int index) {
        if (index < 0 || index > count)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + count);
        URNode<E> terminator = head;

        for (int i = 0; i <= index; i++) {
            terminator = terminator.next();
        }
        URNode<E> predecessor = terminator.prev();
        URNode<E> successor = terminator.next();

        //remove at tail
        if (successor == null) {
            predecessor.setNext(null);
            terminator.setPrev(null);
            tail = predecessor;
            count--;
        } //remove elsewhere
        else {
            predecessor.setNext(successor);
            successor.setPrev(predecessor);
            count--;
        }
        return terminator.element();
    }

    // Removes the first occurrence of the specified element from this list,
    // if it is present
    public boolean remove(Object o) {
        if (indexOf(o) == -1) return false;
        else {
            remove(indexOf(o));
            return true;
        }
    }

    // Removes from this list all of its elements that are contained
    //  in the specified collection
    public boolean removeAll(Collection<?> c) {
        Iterator<?> iter = c.iterator();

        while (iter.hasNext()) {
            remove(iter.next());
        }
        return true;
    }

    // Replaces the element at the specified position in this list
    // with the specified element
    public E set(int index, E element) {
        if (index < 0 || index > count)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + count);
        URNode<E> look = head;

        for (int i = 0; i <= index; i++) {
            look = look.next();
        }
        look.setElement(element);
        return element;
    }

    // Returns the number of elements in this list.
    public int size() {
        return count;
    }

    // Returns a view of the portion of this list
    // between the specified fromIndex, inclusive, and toIndex, exclusive.
    public URList<E> subList(int fromIndex, int toIndex) {
        if ((fromIndex < 0 || fromIndex > count) && (toIndex < 0 || toIndex > count))
            throw new IndexOutOfBoundsException("Index from:" + fromIndex + " Index to: " + toIndex + ", Size: " + count);
        int copy_length = toIndex - fromIndex;

        URLinkedList<E> sublist = new URLinkedList<E>();
        URNode<E> original = head;
        //sets the node original_prev to the node at start index
        for (int i = 0; i <= fromIndex; i++) {
            original = original.next();
        }
        URNode<E> copy_prev = sublist.head;

        for (int i = 0; i < copy_length; i++) {
            URNode<E> copy_entry = new URNode<E>(original.element(), copy_prev, null);
            copy_prev.setNext(copy_entry);
            copy_prev = copy_entry;
            original = original.next();
        }
        sublist.tail = copy_prev;
        return (URList<E>) sublist;
    }

    // Returns an array containing all of the elements in this list
    //  in proper sequence (from first to the last element).
    public Object[] toArray() {
        Object[] result_array = new Object[count];
        URNode<E> look = head;

        for (int i = 0; i < count - 1; i++) {
            result_array[i] = look.next().element();
        }
        return result_array;
    }

    // Inserts the specified element at the beginning of this list.
    public void addFirst(E e) {
        add(0, e);
    }

    // Appends the specified element to the end of this list.
    public void addLast(E e) {
        add(e);
    }

    // Retrieves, but does not remove, the first element of this list, or returns null if this list is empty.
    public E peekFirst() {
        if (head.next() != null) {
            return head.next().element();
        } else {
            return null;
        }

    }

    // Retrieves, but does not remove, the last element of this list, or returns null if this list is empty.
    public E peekLast() {

        return tail.element();
    }

    // Retrieves and removes the first element of this list, or returns null if this list is empty.
    public E pollFirst() {
        E value = head.next().element();
        remove(0);
        return value;

    }

    // Retrieves and removes the last element of this list, or returns null if this list is empty.
    public E pollLast() {
        E value = tail.element();
        remove(count - 1);
        return value;

    }
}

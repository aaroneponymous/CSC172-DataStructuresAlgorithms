/*
@Author: Aaron Paul
apaul9@u.rochester.edu
*/


import java.io.*;



public class URCalculator {
    public URStack<Double> operandURStack; // Stack to store operands
    URQueue postfixURQueue;// Queue to store the postfix expression
    public URStack<String> operatorURStack; // Stack to store operators
    public URLinkedList<Double> finalResults; // Stack to store final results
    public static double[] results;
    int count = 0;


    public URCalculator() {
        operandURStack = new URStack<>();
        postfixURQueue = new URQueue();
        operatorURStack = new URStack<>();
        this.finalResults = new URLinkedList<>();
    }

    public void convertToPostfix(String infix) {

        // Use a StringBuilder to store the current decimal number
        StringBuilder decimalNumber = new StringBuilder();



        // Loop through each character in the infix expression
        for (int i = 0; i < infix.length() + 1; i++) {
            if ((i > infix.length()-1) ) {
                postfixURQueue.enqueue(decimalNumber.toString());
                break;
            }
            char c = infix.charAt(i);

            // If the character is a digit or a decimal point, append it to the decimal number
            if ((Character.isDigit(c) || c == '.')) {
                decimalNumber.append(c);
            } else {
                // If the decimal number is not empty, add it to the postfix expression queue
                int decimalNumberLength = decimalNumber.length();
                if (decimalNumber.length() > 0) {
                    postfixURQueue.enqueue(decimalNumber.toString());
                    decimalNumber.setLength(0); // Clear the decimal number
                } else if (isOperator(c)) {
                    // If the operator stack is empty, push the operator onto the stack
                    if (operatorURStack.isEmpty()) {
                        operatorURStack.push(Character.toString(c));
                    }    // If the operator stack is not empty, check the top element of the stack
                    else {
                        // If the top element has higher precedence than the current operator,
                        // pop the top element from the stack and append it to the postfix expression queue
                        // Then, push the current operator onto the stack
                        if (hasPrecedence(operatorURStack.peek(), Character.toString(c))) {
                            postfixURQueue.enqueue(operatorURStack.pop());
                            operatorURStack.push(Character.toString(c));
                        }
                        // If the top element has equal or lower precedence than the current operator,
                        // push the current operator onto the stack
                        else {
                            operatorURStack.push(Character.toString(c));
                        }
                    }
                }
                // If the character is an opening parenthesis, push it onto the stack
                else if (c == '(') {
                    operatorURStack.push(Character.toString(c));
                }
                // If the character is a closing parenthesis, pop operators from the stack
                // and append them to the postfix expression queue until an opening parenthesis is found.
                // Pop and discard the opening parenthesis.
                else if (c == ')') {
                    while (!operatorURStack.peek().equals("(")) {
                        postfixURQueue.enqueue(operatorURStack.pop());
                    }
                    operatorURStack.pop();
                }

            }

        }

        // Pop any remaining operators from the stack and append them to the postfix expression queue
        while (!operatorURStack.isEmpty()) {
            postfixURQueue.enqueue(operatorURStack.pop());
        }

    }


    // Method to compare the precedence of two operators
    private boolean hasPrecedence(String op1, String op2) {
        // Get the precedence of the two operators
        int precedence1 = 0;
        int precedence2 = 0;

        // Assign a precedence value to each operator
        switch (op1) {
            case "!":
                precedence1 = 1;
                break;
            case "&":
                precedence1 = 2;
                break;
            case "|":
                precedence1 = 3;
                break;
            case "=":
                precedence1 = 4;
                break;
            case ">":
            case "<":
                precedence1 = 5;
                break;
            case "~":
                precedence1 = 6;
                break;
            case "+":
            case "-":
                precedence1 = 7;
                break;
            case "*":
            case "/":
            case "%":
                precedence1 = 8;
                break;
            case "^":
                precedence1 = 9;
                break;
            case "(":
            case ")":
                precedence1 = 10;
                break;
            case "sin":
            case "cos":
            case "tan":
                precedence1 = 11;
                break;
        }
        switch (op2) {
            case "!":
                precedence2 = 1;
                break;
            case "&":
                precedence2 = 2;
                break;
            case "|":
                precedence2 = 3;
                break;
            case "=":
                precedence2 = 4;
                break;
            case ">":
            case "<":
                precedence2 = 5;
                break;
            case "~":
                precedence2 = 6;
                break;
            case "+":
            case "-":
                precedence2 = 7;
                break;
            case "*":
            case "/":
            case "%":
                precedence2 = 8;
                break;
            case "^":
                precedence2 = 9;
                break;
            case "(":
            case ")":
                precedence2 = 10;
                break;
            case "sin":
            case "cos":
            case "tan":
                precedence2 = 11;
                break;
        }

        // Return true if the operator on the stack has lower precedence than the current operator
        return precedence1 < precedence2;
    }

    // This method checks if a character is an operator
    private boolean isOperator(char c) {
        // Use a switch statement to check if the character is an operator
        switch (c) {
            // Return true if the character is an operator, false otherwise
            case '+':
            case '-':
            case '*':
            case '/':
            case '^':
            case '=':
            case '>':
            case '<':
            case '&':
            case '|':
            case '~':
            case '!':
            case '%':
                return true;
            default:
                return false;
        }
    }

    public void readInfixfromFile(String fileName) {
        // Use a try-with-resources block to automatically close the file after reading
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;

            // Read each line of the file until the end of the file is reached
            while ((line = reader.readLine()) != null) {

                // Parse the line and convert it to postfix notation
                convertToPostfix(line);
                // Evaluate the postfix expression
                evaluatePostfix(postfixURQueue);

            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
    }

    public void evaluatePostfix(URQueue postfixURQueue) {

        // Loop through each token in the queue
        while (!postfixURQueue.isEmpty()) {
            String token = postfixURQueue.dequeue();

            // If the token is an operand, push it onto the stack
            if (isOperand(token)) {
                operandURStack.push(Double.valueOf(token));

            }
            // If the token is an operator, perform the following steps:
            else if (isOperator(token)) {
                // Pop the appropriate number of operands from the stack
                int numOperands = getNumOperands(token);
                double[] operands = new double[numOperands];
                for (int i = numOperands; i > 0; i--) {
                    operands[i-1] = Double.parseDouble(String.valueOf(operandURStack.pop()));
                }

                // Perform the operation on the popped operands, and push the resulting value onto the stack
                double result = performOperation(token, operands);
                operandURStack.push(Double.valueOf(Double.toString(result)));
            }
        }

        finalResults.add(operandURStack.pop());
    }


    // Method to perform an operation on a given set of operands
    public double performOperation(String operator, double[] operands) {
        // Perform the operation depending on the operator
        switch (operator) {
            case "+":
                return operands[0] + operands[1];
            case "-":
                return operands[0] - operands[1];
            case "*":
                return operands[0] * operands[1];
            case "/":
                return operands[0] / operands[1];
            case "^":
                return Math.pow(operands[0], operands[1]);
            case "=":
                return operands[0] == operands[1] ? 1 : 0;
            case "<":
                return operands[0] < operands[1] ? 1 : 0;
            case ">":
                return operands[0] > operands[1] ? 1 : 0;
            case "&":
                return operands[0] != 0 && operands[1] != 0 ? 1 : 0;
            case "|":
                return operands[0] != 0 || operands[1] != 0 ? 1 : 0;
            case "!":
                return operands[0] != 0 ? 0 : 1;
            case "%":
                return operands[0] % operands[1];
            case "sin":
                return Math.sin(operands[0]);
            case "cos":
                return Math.cos(operands[0]);
            case "tan":
                return Math.tan(operands[0]);
            default:
                return 0;
        }
    }

    // Method to check if a token is an operand (i.e. a number)
    public boolean isOperand(String token) {
        // Check if the token is a number
        // This can be done by attempting to parse it as a double and catching any exceptions
        try {
            Double.parseDouble(token);
            return true;
        } catch (NumberFormatException e) {
            if (token.equals(".")) {
                return true;
            } else {
                return false;
            }
        }
    }

    // Method to check if a token is an operator
    public boolean isOperator(String token) {
        // Check if the token is one of the supported operators
        switch (token) {
            case "+":
            case "-":
            case "*":
            case "/":
            case "^":
            case "=":
            case "<":
            case ">":
            case "&":
            case "|":
            case "!":
            case "%":
                return true;
            default:
                return false;
        }
    }

    // Method to get the number of operands required by an operator
    public int getNumOperands(String token) {
        // Most operators require 2 operands, except for logical NOT, which requires only 1
        return token.equals("!") ? 1 : 2;
    }

    public void writeToFile(String fileName, double[] results) {
        // Use a try-with-resources block to automatically close the file after writing
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            // Loop through each result in the array and write it to the file
            for (Double result : finalResults) {
                writer.write(Double.toString(result));
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }
    }






    public static void main(String[] args) {

        // Create a new instance of the URCalculator
        URCalculator urCalculator = new URCalculator();

        // Get the names of the input and output files from the command-line arguments
        String inputFile = args[0];
        String outputFile = args[1];

        // Read in the infix expressions from the input file and convert them to postfix notation
        urCalculator.readInfixfromFile(inputFile);



        // Save the results to the output file using the writeToFile method
        urCalculator.writeToFile(outputFile, results);
    }
}

public class URQueue {

    //field
    private URLinkedList<String> linkedlist;

    //constructor
    public URQueue() {
        this.linkedlist = new URLinkedList<String>();
    }

    public void enqueue(String c) {
        linkedlist.add(c);
    }

    public String dequeue() {
        return (String) linkedlist.pollFirst();
    }

    public String peek() {
        return (String) linkedlist.peekFirst();
    }

    public boolean isEmpty() {
        return linkedlist.isEmpty();
    }

    public int size() {
        return linkedlist.size();
    }
}

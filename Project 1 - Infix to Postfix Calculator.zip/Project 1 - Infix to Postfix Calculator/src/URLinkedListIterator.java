import java.util.Iterator;
import java.util.NoSuchElementException;

public class URLinkedListIterator<E> implements Iterator<E> {

        URLinkedList<E> list;
        URNode<E> curr;

        public URLinkedListIterator(URLinkedList<E> list) {
            this.list = list;
            this.curr = list.head;
        }

        @Override
        public boolean hasNext() {
            return this.curr.next() != null;
        }

        @Override
        public E next() {
            if (!this.hasNext()) {
                throw new NoSuchElementException();
            } else {
                this.curr = this.curr.next();
                return this.curr.element();
            }
        }

}

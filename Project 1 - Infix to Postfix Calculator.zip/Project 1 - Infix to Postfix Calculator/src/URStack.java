public class URStack<T> {
    public URLinkedList<T> linkedlist;

    public URStack() {
        this.linkedlist = new URLinkedList<T>();
    }

    public void push(T c) {
        linkedlist.addFirst(c);
    }

    //what does empty stack return?
    public T pop() {
        return (T) linkedlist.pollFirst();
    }

    public T peek() {
        if (!this.isEmpty()) {
            return (T) linkedlist.peekFirst();
        }
        else return null;

    }

    public int size() {
        return linkedlist.size();
    }


    public boolean isEmpty() {
        return linkedlist.isEmpty();
    }

}
